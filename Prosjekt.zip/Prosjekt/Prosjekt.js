(function () {
  const holder = document.getElementById("loaderText");

  if (holder) {
    const text = holder.getAttribute("data-text") || "Online & Aksjon";
    holder.textContent = "";

    const chars = Array.from(text);
    const fragment = document.createDocumentFragment();
    let visualIndex = 0;

    chars.forEach((ch) => {
      if (ch === " ") {
        const sp = document.createElement("span");
        sp.className = "loader-space";
        sp.innerHTML = "&nbsp;";
        fragment.appendChild(sp);
        return;
      }

      const span = document.createElement("span");
      span.className = "loader-char";
      span.style.setProperty("--i", String(visualIndex));
      span.textContent = ch;

      fragment.appendChild(span);
      visualIndex++;
    });

    holder.appendChild(fragment);

    const staggerMs = 65;
    const dropMs = 760;
    const holdMs = 450;
    const totalMs = (Math.max(0, visualIndex - 1) * staggerMs) + dropMs + holdMs;

    document.addEventListener("DOMContentLoaded", () => {
      setTimeout(() => {
        document.body.classList.add("loaded");
      }, totalMs);
    });
  }

  const cards = document.querySelectorAll(".info-card");
  const popup = document.getElementById("cardPopup");
  const popupImg = document.getElementById("popupImg");
  const popupTitle = document.getElementById("popupTitle");
  const popupDesc = document.getElementById("popupDesc");
  const imageCredit = document.getElementById("imageCredit");
  const closePopup = document.getElementById("closePopup");
  if (cards.length && popup && popupImg && popupTitle && popupDesc && imageCredit && closePopup) {
    cards.forEach(card => {
      card.addEventListener("click", () => {
        popupImg.src = card.dataset.img;
        popupImg.alt = card.dataset.title || "";
        popupTitle.textContent = card.dataset.title || "";
        popupDesc.textContent = card.dataset.desc || "";
        imageCredit.textContent = card.dataset.credit || "";
        popup.classList.add("show");
        document.body.style.overflow = "hidden";
      });
    });

    closePopup.addEventListener("click", () => {
      popup.classList.remove("show");
      document.body.style.overflow = "";
    });

    popup.addEventListener("click", (e) => {
      if (e.target === popup) {
        popup.classList.remove("show");
        document.body.style.overflow = "";
      }
    });

    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        popup.classList.remove("show");
        document.body.style.overflow = "";
      }
    });
  }
    const youtubeWrapper = document.getElementById("youtubeVideoWrapper");
  const youtubeVideo = document.getElementById("youtubeVideo");

  if (youtubeWrapper && youtubeVideo) {
    const originalSrc = "https://www.youtube.com/embed/os2TKzKF9po?enablejsapi=1&mute=1&rel=0";
    const autoplaySrc = "https://www.youtube.com/embed/os2TKzKF9po?enablejsapi=1&autoplay=1&mute=1&rel=0";

    let hasPlayed = false;

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting && !hasPlayed) {
          youtubeVideo.src = autoplaySrc;
          hasPlayed = true;
        }
      });
    }, {
      threshold: 0.6
    });

    observer.observe(youtubeWrapper);
  }
})();