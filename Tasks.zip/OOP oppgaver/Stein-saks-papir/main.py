from PyQt5 import QtWidgets, uic
import sys
from PyQt5.QtGui import *
import random

class Ui(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui, self).__init__()
        uic.loadUi('Spill.ui', self)
        self.show()

        self.pushButton_1 = self.findChild(QtWidgets.QPushButton, 'pushButton')
        self.pushButton_2 = self.findChild(QtWidgets.QPushButton, 'pushButton_2')
        self.pushButton_3 = self.findChild(QtWidgets.QPushButton, 'pushButton_3')

        self.label = self.findChild(QtWidgets.QLabel, 'label')
        self.label_2 = self.findChild(QtWidgets.QLabel, 'label_2')

        self.pushButton_1.setIcon(QIcon(QPixmap("1.bmp")))
        self.pushButton_2.setIcon(QIcon(QPixmap("2.bmp")))
        self.pushButton_3.setIcon(QIcon(QPixmap("3.bmp")))

        self.pushButton_1.setIconSize(self.pushButton_1.size())
        self.pushButton_2.setIconSize(self.pushButton_2.size())
        self.pushButton_3.setIconSize(self.pushButton_3.size())

        self.pushButton_1.setText("")
        self.pushButton_2.setText("")
        self.pushButton_3.setText("")

        self.pushButton_1.clicked.connect(self.check)
        self.pushButton_2.clicked.connect(self.check)
        self.pushButton_3.clicked.connect(self.check)

    def check(self):
        gra = ["1.bmp","2.bmp","3.bmp"]
        k = random.randint(0,2)
        pic = QPixmap(gra[k])
        self.label.setScaledContents(True)
        self.label.setPixmap(pic)

        btn_name = self.sender().objectName()
        if btn_name == "pushButton":
            n = 0
        elif btn_name == "pushButton_2":
            n = 1
        elif btn_name == "pushButton_3":
            n = 2

        if n == k:
            self.label_2.setText("Uavgjort")
        elif (n == 0 and k == 1) or (n == 1 and k == 2) or (n == 2 and k == 0):
            self.label_2.setText("Du vant")
        else:
            self.label_2.setText("Datamaskinen vant")

app = QtWidgets.QApplication(sys.argv)
window = Ui()
app.exec_()

