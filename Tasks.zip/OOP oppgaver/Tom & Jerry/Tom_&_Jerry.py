from PyQt5 import QtWidgets, uic
import sys
from PyQt5.QtGui import *


class Ui(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui, self).__init__()
        uic.loadUi('Tom & Jerry.ui', self)
        self.show()

        self.pushButton = self.findChild(QtWidgets.QPushButton, 'pushButton')
        self.pushButton_2 = self.findChild(QtWidgets.QPushButton, 'pushButton_2')
        self.pushButton_3 = self.findChild(QtWidgets.QPushButton, 'pushButton_3')
        self.pushButton_4 = self.findChild(QtWidgets.QPushButton, 'pushButton_4')
        self.pushButton_5 = self.findChild(QtWidgets.QPushButton, 'pushButton_5')

        self.pushButton.clicked.connect(self.Hoppe)
        self.pushButton_2.clicked.connect(self.Hoppe_2)
        self.pushButton_3.clicked.connect(self.Hoppe_3)
        self.pushButton_4.clicked.connect(self.Hoppe_4)
        self.pushButton_5.clicked.connect(self.Hoppe_5)

        self.label.setText("Tom")
        self.label_2.setText("Jerry")
        self.label_3.setText("")

    def Hoppe(self):
         if self.label_3.text() == "":
            self.label.setText("")
            self.label_3.setText("Tom")
        
    def Hoppe_2(self):
        if self.label_3.text() == "":
            self.label_2.setText("")
            self.label_3.setText("Jerry")
        
    def Hoppe_3(self):
        if self.label_4.text() == "":
            self.label_3.setText("")
            self.label_4.setText("Jerry")

    def Hoppe_4(self):
        if self.label_5.text() == "":
            self.label_4.setText("")
            self.label_5.setText("Jerry")

    def Hoppe_5(self):
        if self.label_5.text() == "Jerry":
            self.label_3.setText("")
            self.label_5.setText("Tom")
        elif self.label_5.text() == "Tom":
            self.label_5.setText("")
            self.label.setText("Tom")

app = QtWidgets.QApplication(sys.argv)
window = Ui()
app.exec_()