from PyQt5 import QtCore, QtGui, QtWidgets, uic
import sys

class Ui_MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui_MainWindow, self).__init__()
        uic.loadUi('Thama_interfeis.ui', self)
        self.show()

        self.pushButton_4.clicked.connect(lambda x: QtCore.QCoreApplication.quit())
        self.pushButton_5.clicked.connect(self.talks)
        self.pushButton_6.clicked.connect(self.eats)
        self.pushButton_7.clicked.connect(self.plays)

        self.tama = Tamagochi("Barbos")
        self.textEdit.setText(f"Hei, Jeg heter {self.tama.name}! Jeg føler meg {self.tama.mood}")

    def talks(self):
        self.tama.talk()
        self.textEdit.setText(f"Hei, Jeg heter {self.tama.name}! Jeg føler meg {self.tama.mood}" )

    def plays(self):
        self.tama.play()
        self.textEdit.setText(f"Jeg har lekt! Nå føler jeg meg {self.tama.mood}.")

    def eats(self):
        self.tama.eat()
        self.textEdit.setText(f"Nam nam! Takk for maten. Nå føler jeg meg {self.tama.mood}.")

class Tamagochi:
    totalt = 0
    
    def __init__(self, name, hunger = 0, boredom = 0):
        self.name = name
        print("A new animal is born")
        Tamagochi.totalt += 1
        self.hunger = hunger
        self.boredom = boredom

    def talk(self):
        print('Hello, I am Tamagoci!', self.name, "I feel", self.mood)

    def check(self):
        print("I'm good")

    def pass_time(self):
        self.hunger += 1
        self.boredom += 1

    def eat(self, food = 4):
        print("Thanks!")
        self.hunger -= food
        if self.hunger < 0:
            self.hunger = 0
        self.pass_time()

    def play(self, fun = 4):
        print("Hahahah")
        self.boredom -= fun
        if self.boredom < 0:
            self.boredom = 0
        self.pass_time()

    def __str__(self):
        re = "Object:" + self.name
        return(re)
    
    @property
    def mood(self):
        unhappiness = self.hunger + self.boredom
        if unhappiness < 5:
            m = "great"
        elif 5 <= unhappiness <= 10:
            m = "good",
        elif 11 <= unhappiness <= 15:
            m = "ok"
        else:
            m = "bad"
        return m


app = QtWidgets.QApplication(sys.argv)
window = Ui_MainWindow()
app.exec_()