class Tamagochi:
    totalt = 0
    
    def __init__(self, name, hunger = 0, boredom = 0):
        self.name = name
        print("A new animal is born")
        Tamagochi.totalt += 1
        self.hunger = hunger
        self.boredom = boredom

    def talk(self):
        print('Hello, I am Tamagoci!', self.name, "I feel", self.mood)

    def check(self):
        print("I'm good")

    def pass_time(self):
        self.hunger += 1
        self.boredom += 1

    def eat(self, food = 4):
        print("Thanks!")
        self.hunger -= food
        if self.hunger < 0:
            self.hunger = 0
        self.pass_time()

    def play(self, fun = 4):
        print("Hahahah")
        self.boredom -= fun
        if self.boredom < 0:
            self.boredom = 0
        self.pass_time()

    def __str__(self):
        re = "Object:" + self.name
        return(re)
    
    @property
    def mood(self):
        unhappiness = self.hunger + self.boredom
        if unhappiness < 5:
            m = "great"
        elif 5 <= unhappiness <= 10:
            m = "good",
        elif 11 <= unhappiness <= 15:
            m = "ok"
        else:
            m = "bad"
        return m
 
tama = Tamagochi("Barbos")
tama.talk()


status = True
while status:
    print(
        f"What would you like to do?\n"
        f"0 - exit\n"
        f"1 - check\n"
        f"2 - eat\n"
        f"3 - play\n"
    )

    x = int(input('I would like...'))
    if x == 0:
        print('Program is close.')
        status = False
    elif x == 1:
        tama.check()
    elif x == 2:
        tama.eat()
    elif x == 3:
        tama.play()
    else:
        print('Error!')
