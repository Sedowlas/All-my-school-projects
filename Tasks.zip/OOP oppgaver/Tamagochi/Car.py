class Car:
    def __init__(self, name, color):
        self.name = name
        self.color = color
    def __str__(self):
        return (self.name + ' ' + self.color)
   
a = Car('Fibi', 'Red')
print(a)
 
class Bil:
    def __init__(self, name, color):
        self.name = name
        self.color = color
        self.gas = 100
    def load(self, a):
        self.gas += a
    def tank(self):
        return(self.gas)
    def info(self):
        return print(f'{self.name} {self.color} {self.gas}')
 
fabia = Bil('Fabia','White')
fabia.load(50)
print(fabia.tank())
fabia.info()