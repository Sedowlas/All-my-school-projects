from PyQt5 import QtCore, QtGui, QtWidgets, uic
import sys

class Ui_MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui_MainWindow, self).__init__()
        uic.loadUi('qt_designer_dritt.ui', self)
        self.show()

        self.pushButton.clicked.connect(self.printButtonPressed)
        self.pushButton_2.clicked.connect(self.printButtonPressed_2)

    def printButtonPressed(self):
        imya = self.lineEdit.text()
        self.label.setText(imya)
        print(imya)

    def printButtonPressed_2(self):
        self.label.setText("")
        print("Clear")

app = QtWidgets.QApplication(sys.argv)
window = Ui_MainWindow()
app.exec_()