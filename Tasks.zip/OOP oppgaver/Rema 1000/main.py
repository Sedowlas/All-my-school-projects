from PyQt5 import QtWidgets, uic
import sys
from PyQt5.QtGui import *

class Ui(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui, self).__init__()
        uic.loadUi('rema1000.ui', self)
        self.show()

        self.btn_agurk = self.findChild(QtWidgets.QPushButton, 'pushButton')
        self.btn_banan = self.findChild(QtWidgets.QPushButton, 'pushButton_2')
        self.btn_galubtsi = self.findChild(QtWidgets.QPushButton, 'pushButton_3')
        self.btn_pomidor = self.findChild(QtWidgets.QPushButton, 'pushButton_4')
        self.btn_pelmeni = self.findChild(QtWidgets.QPushButton, 'pushButton_5')
        self.btn_romme = self.findChild(QtWidgets.QPushButton, 'pushButton_6')

        self.btn_svin = self.findChild(QtWidgets.QPushButton, 'pushButton_7')
        self.btn_kjott = self.findChild(QtWidgets.QPushButton, 'pushButton_8')
        self.btn_kylling = self.findChild(QtWidgets.QPushButton, 'pushButton_9')
        self.btn_sitron = self.findChild(QtWidgets.QPushButton, 'pushButton_10')
        self.btn_lok = self.findChild(QtWidgets.QPushButton, 'pushButton_11')
        self.btn_potet = self.findChild(QtWidgets.QPushButton, 'pushButton_12')

        self.btn_betal = self.findChild(QtWidgets.QPushButton, 'pushButton_13')

        self.btn_agurk.clicked.connect(lambda:self.add_item('agurk'))
        self.btn_banan.clicked.connect(lambda:self.add_item('banan'))
        self.btn_galubtsi.clicked.connect(lambda:self.add_item('galubtsi'))
        self.btn_pomidor.clicked.connect(lambda:self.add_item('pomidor'))
        self.btn_pelmeni.clicked.connect(lambda:self.add_item('pelmeni'))
        self.btn_romme.clicked.connect(lambda:self.add_item('romme'))
        self.btn_svin.clicked.connect(lambda:self.add_item('svin'))
        self.btn_kjott.clicked.connect(lambda:self.add_item('kjott'))
        self.btn_kylling.clicked.connect(lambda:self.add_item('kylling'))
        self.btn_sitron.clicked.connect(lambda:self.add_item('sitron'))
        self.btn_lok.clicked.connect(lambda:self.add_item('lok'))
        self.btn_potet.clicked.connect(lambda:self.add_item('potet'))
        self.btn_betal.clicked.connect(lambda:self.add_item('betal'))

    def add_item(self, item):
        self.label_3.setText(self.label_3.text() + item + '\n')

    # def penger(self, item):
    #     if self.label_2.text() == "1000 kr" and item == item:

    def total_sum(self):


app = QtWidgets.QApplication(sys.argv)
window = Ui()
app.exec_()