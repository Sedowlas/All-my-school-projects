from PyQt5 import QtWidgets, uic
import sys
from PyQt5.QtGui import *


class Ui(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui, self).__init__()
        uic.loadUi('Travel.ui', self)

        self.pushButton = self.findChild(QtWidgets.QPushButton, 'pushButton')
        self.pushButton_2 = self.findChild(QtWidgets.QPushButton, 'pushButton_2')
        self.pushButton_3 = self.findChild(QtWidgets.QPushButton, 'pushButton_3')

        self.pushButton.clicked.connect(self.London)
        self.pushButton_2.clicked.connect(self.Berlin)
        self.pushButton_3.clicked.connect(self.Oslo)

        self.checkBox = self.findChild(QtWidgets.QCheckBox, 'checkBox')
        self.label = self.findChild(QtWidgets.QLabel, 'label')
        self.label_2 = self.findChild(QtWidgets.QLabel, 'label_2')
        
        self.show()

    def London(self):
        self.label_2.setText("London is the capital of Great Britain") # fyll tekstetikett
        if self.checkBox.isChecked(): # hvis CheckBox er merket
            pixmap = QPixmap('London_night.jpg') # skriv bildet London_night.jpg inn i pixmap-variabelen
        else:
            pixmap = QPixmap('London_day.jpg') # skriv bildet London_day.jpg inn i pixmap-variabelen
        self.label.setPixmap(pixmap) # vis bildet i Label
        self.label.resize(450,450) # angi bildestørrelse
        self.label.setScaledContents(True) # bildet er jevnt skalert til den angitte størrelsen

    def Berlin(self):
        self.label_2.setText("Berlin is the capital of Germany") # fyll tekstetikett
        if self.checkBox.isChecked(): # hvis CheckBox er merket
            pixmap = QPixmap('Berlin_night.jpg') # skriv bildet Berlin_night.jpg inn i pixmap-variabelen
        else:
            pixmap = QPixmap('Berlin_day.jpg') # skriv bildet Berlin_day.jpg inn i pixmap-variabelen
        self.label.setPixmap(pixmap) # vis bildet i Label
        self.label.resize(450,450) # angi bildestørrelse
        self.label.setScaledContents(True) # bildet er jevnt skalert til den angitte størrelsen

    def Oslo(self):
        self.label_2.setText("Oslo is the capital of Norway") # fyll tekstetikett
        if self.checkBox.isChecked(): # hvis CheckBox er merket
            pixmap = QPixmap('Oslo_night.jpg') # skriv bildet Oslo_night.jpg inn i pixmap-variabelen
        else:
            pixmap = QPixmap('Oslo_day.jpg') # skriv bildet Oslo_day.jpg inn i pixmap-variabelen
        self.label.setPixmap(pixmap) # vis bildet i Label
        self.label.resize(450,450) # angi bildestørrelse
        self.label.setScaledContents(True) # bildet er jevnt skalert til den angitte størrelsen

app = QtWidgets.QApplication(sys.argv)
window = Ui()
app.exec_()